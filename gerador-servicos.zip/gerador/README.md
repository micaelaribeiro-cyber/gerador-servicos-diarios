# Gerador de Serviços Diários

Aplicativo web (HTML + CSS + JavaScript + SheetJS) que lê o relatório de OS, exclui os assuntos RETIRADA e gera um Excel com 7 abas por localidade. Tudo roda no navegador; nenhum arquivo é enviado a servidores.

## Publicar (sem instalar nada)
1. **Biblioteca**: baixe https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js (botão direito > Salvar como) e salve como `vendor/xlsx.bundle.js` nesta pasta. (xlsx-js-style é o SheetJS com suporte a estilos; sem estilos o cabeçalho não ganha cor.) Se não fizer isso, o app tenta baixá-la do jsDelivr ao gerar.
2. Em github.com: **New repository** > nome `gerador-servicos` > **Public** (Pages gratuito exige público em contas free; o repositório só tem código, nunca relatórios) > **Create repository**.
3. **uploading an existing file** > arraste *o conteúdo* desta pasta (index.html, css, js, tests, vendor, README.md, .gitignore) > **Commit changes**.
4. **Settings > Pages > Build and deployment**: Source = *Deploy from a branch*, Branch = `main`, pasta `/ (root)` > **Save**.
5. Após ~1 a 2 minutos o link aparece no topo da página: `https://SEU-USUARIO.github.io/gerador-servicos/`.
6. **Atualizar**: abra o arquivo no repositório > lápis (Edit) > Commit, ou **Add file > Upload files** substituindo o arquivo. O site atualiza sozinho em poucos minutos.

## Testes
`node tests/test-processor.js` (opcional, exige Node) valida a lógica com dados sintéticos.

## Regras
- RETIRADA: exclui assuntos que contenham a palavra "retirada" (a tela lista o que foi excluído).
- Complementos (sem acento/caixa/espaços extras): Itabatã, Mucuri, Nova Viçosa, Posto da Mata, Nanuque, Serra dos Aimorés; o resto vai para Cidades Externas.
- Ordenação em cada aba: Agendamento, Colaborador, Cliente.
